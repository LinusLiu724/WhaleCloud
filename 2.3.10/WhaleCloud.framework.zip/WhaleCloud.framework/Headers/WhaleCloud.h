#import <Foundation/Foundation.h>
FOUNDATION_EXPORT double WhaleCloudVersionNumber;
FOUNDATION_EXPORT const unsigned char WhaleCloudVersionString[];
